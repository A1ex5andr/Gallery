angular.module('scopeTest', [])

    .controller('FirstCtrl', function () {

    }).controller('SecondCtrl', function () {

});
